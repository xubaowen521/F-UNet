import random
import torch
import torch.nn as nn
from layers.Invertible import RevIN
def sampler(obs_len,sample_ratio):
    sample = []
    i = 0
    sample_len = int(obs_len*sample_ratio)
    while i < sample_len:
        a = random.uniform(0,obs_len)
        a = int(a)
        if a not in sample:
            sample.append(a)
            i += 1
        else:
            continue
    return sorted(sample)

def batchmul1d(input, weights):
    # (batch, in_channel, x), (in_channel, out_channel, x) -> (batch, out_channel, x)
    return torch.einsum("bix,iox->box", input, weights)

class SpectralConv1d(nn.Module):
    """1D Fourier layer. Does FFT, linear transform, and Inverse FFT.
    Implemented in a way to allow multi-gpu training.
    Args:
        in_channels (int): Number of input channels
        out_channels (int): Number of output channels
        modes (int): Number of Fourier modes
    [paper](https://arxiv.org/abs/2010.08895)
    """

    def __init__(self, in_channels: int, out_channels: int, modes: int):
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes = modes

        self.scale = 1 / (in_channels * out_channels)
        self.weights = nn.Parameter(
            self.scale * torch.rand(in_channels, out_channels, self.modes, 2, dtype=torch.float32)
        )

    def forward(self, x):
        batchsize = x.shape[0]
        # Compute Fourier coeffcients up to factor of e^(- something constant)
        x_ft = torch.fft.rfft(x)

        # Multiply relevant Fourier modes
        out_ft = torch.zeros(
            batchsize,
            self.out_channels,
            x.size(-1) // 2 + 1,
            dtype=torch.cfloat,
            device=x.device,
        )
        out_ft[:, :, : self.modes] = batchmul1d(
            x_ft[:, :, : self.modes], torch.view_as_complex(self.weights)
        )

        # Return to physical space
        x = torch.fft.irfft(out_ft, n=(x.size(-1)))
        return x


class ResidualBlock(nn.Module):
    """Wide Residual Blocks used in modern Unet architectures.

    Args:
        in_channels (int): Number of input channels.
        out_channels (int): Number of output channels.
        activation (str): Activation function to use.
        norm (bool): Whether to use normalization.
        n_groups (int): Number of groups for group normalization.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
    ):
        super().__init__()
        self.activation = nn.GELU()
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size=3, padding=1)
        self.norm = nn.LayerNorm(out_channels)

    def forward(self, x: torch.Tensor):
        h = self.norm(self.activation(self.conv(x)).permute(0, 2, 1)).permute(0, 2, 1)
        return h


class FourierResidualBlock(nn.Module):
    """Fourier Residual Block to be used in modern Unet architectures.

    Args:
        in_channels (int): Number of input channels.
        out_channels (int): Number of output channels.
        modes1 (int): Number of modes in the first dimension.
        modes2 (int): Number of modes in the second dimension.
        activation (str): Activation function to use.
        norm (bool): Whether to use normalization.
        n_groups (int): Number of groups for group normalization.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        modes: int = 16
    ):
        super().__init__()
        self.modes = modes
        self.activation = nn.GELU()
        self.fourier = SpectralConv1d(in_channels, out_channels, modes=self.modes)
        self.norm = nn.LayerNorm(out_channels)



    def forward(self, x: torch.Tensor):
        h_ = self.activation(self.fourier(x))
        h = self.norm(h_.permute(0, 2, 1)).permute(0, 2, 1)
        out = h
        return out


class FourierDownBlock(nn.Module):
    """Down block This combines [`FourierResidualBlock`][pdearena.modules.twod_unet.FourierResidualBlock] and [`AttentionBlock`][pdearena.modules.twod_unet.AttentionBlock].

    These are used in the first half of U-Net at each resolution.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        modes: int = 16,
    ):
        super().__init__()
        self.res = FourierResidualBlock(
            in_channels,
            out_channels,
            modes=modes
        )

    def forward(self, x: torch.Tensor):
        x = self.res(x)
        return x



class FourierUpBlock(nn.Module):
    """Up block that combines [`FourierResidualBlock`][pdearena.modules.twod_unet.FourierResidualBlock] and [`AttentionBlock`][pdearena.modules.twod_unet.AttentionBlock].

    These are used in the second half of U-Net at each resolution.

    Note:
        We currently don't recommend using this block.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        modes: int = 16,
    ):
        super().__init__()
        # The input has `in_channels + out_channels` because we concatenate the output of the same resolution
        # from the first half of the U-Net
        self.res = FourierResidualBlock(
            in_channels,
            out_channels,
            modes=modes
        )
    def forward(self, x: torch.Tensor):
        x = self.res(x)
        return x


class MiddleBlock(nn.Module):
    """Middle block

    It combines a `ResidualBlock`, `AttentionBlock`, followed by another
    `ResidualBlock`.

    This block is applied at the lowest resolution of the U-Net.

    Args:
        n_channels (int): Number of channels in the input and output.
        has_attn (bool, optional): Whether to use attention block. Defaults to False.
        activation (str): Activation function to use. Defaults to "gelu".
        norm (bool, optional): Whether to use normalization. Defaults to False.
    """

    def __init__(self, in_channels: int, out_channels):
        super().__init__()
        n_channels = in_channels * 2
        self.res1 = ResidualBlock(in_channels, out_channels)
        #self.res2 = ResidualBlock(n_channels, out_channels)

    def forward(self, x: torch.Tensor):
        x = self.res1(x)
        #x = self.res2(x)
        return x


class FourierUnet(nn.Module):
    def __init__(self, in_channels=3, out_channels=1, features=[8, 16], #, 8, 16
                 n_blocks=1,  modes=8,  mode_scaling = True):
        super().__init__()

        self.ups = nn.ModuleList()
        self.downs = nn.ModuleList()
        # 定义下采样路径
        for i, feature in enumerate(features):
            for _ in range(n_blocks):
                self.downs.append(
                    FourierDownBlock(
                        in_channels,
                        feature,
                        modes=max(modes // 2 ** i, 4) if mode_scaling else modes
                    )
                )
                in_channels = feature

        # 定义上采样路径
        for  feature in reversed(features):
            self.ups.append(
                FourierUpBlock(
                    feature * 2, feature
                )
            )
            for _ in range(n_blocks):
                self.ups.append(
                    FourierUpBlock(
                        feature * 2, feature
                    )
                )

        # 最后的卷积层输出
        self.middle = MiddleBlock(features[-1], features[-1] * 2 )
        self.final_conv = nn.Conv1d(features[0], out_channels, kernel_size=1)
        #self.final_linear = nn.Linear()

    def forward(self, x):
        '''
        :param x: batch_size, in_channel, agent_number
        :return: batch_size, out_channel, agent_number
        '''
        skip_connections = []

        # 下采样路径
        for down in self.downs:
            x = down(x)
            skip_connections.append(x)
        # 最后的卷积层
        x = self.middle(x)
        # 上采样路径
        for idx in range(0, len(self.ups), 2):
            x = self.ups[idx](x)
            skip_connection = skip_connections[len(skip_connections) - idx // 2 - 1]
            x = torch.cat([x, skip_connection[:, :, :x.shape[-1]]], dim=1)
            x = self.ups[idx + 1](x)

        # 输出结果
        x = self.final_conv(x)
        return x
class Unet(nn.Module):
    def __init__(self, in_channels=3, out_channels=1, features=[8, 16], #, 8, 16
                 n_blocks=1,  modes=8,  mode_scaling = True):
        super().__init__()

        self.ups = nn.ModuleList()
        self.downs = nn.ModuleList()
        # 定义下采样路径
        for i, feature in enumerate(features):
            for _ in range(n_blocks):
                self.downs.append(
                    ResidualBlock(
                        in_channels,
                        feature,
                    )
                )
                in_channels = feature

        # 定义上采样路径
        for  feature in reversed(features):
            self.ups.append(
                ResidualBlock(
                    feature * 2, feature
                )
            )
            for _ in range(n_blocks):
                self.ups.append(
                    ResidualBlock(
                        feature * 2, feature
                    )
                )

        # 最后的卷积层输出
        self.middle = MiddleBlock(features[-1], features[-1] * 2 )
        self.final_conv = nn.Conv1d(features[0], out_channels, kernel_size=1)
        #self.final_linear = nn.Linear()

    def forward(self, x):
        '''
        :param x: batch_size, in_channel, agent_number
        :return: batch_size, out_channel, agent_number
        '''
        skip_connections = []

        # 下采样路径
        for down in self.downs:
            x = down(x)
            skip_connections.append(x)
        # 最后的卷积层
        x = self.middle(x)
        # 上采样路径
        for idx in range(0, len(self.ups), 2):
            x = self.ups[idx](x)
            skip_connection = skip_connections[len(skip_connections) - idx // 2 - 1]
            x = torch.cat([x, skip_connection[:, :, :x.shape[-1]]], dim=1)
            x = self.ups[idx + 1](x)

        # 输出结果
        x = self.final_conv(x)
        return x
#x = torch.rand((32,96,7))
#model = Unet(in_channels=7, out_channels=7)
#y = model(x.transpose(1, 2))
#print(y.shape)
class Model(nn.Module):
    def __init__(self, configs):
        super().__init__()
        self.FUNet = FourierUnet(in_channels=8, out_channels=8)
        #self.FUNet = Unet(in_channels=7, out_channels=7)
        self.projection = nn.Linear(configs.seq_len, configs.pred_len)
        self.rev = RevIN(configs.enc_in) if configs.rev else None

    def forward(self, x):
        x = self.rev(x, 'norm') if self.rev else x
        #print(x.shape)

        x = self.FUNet(x.transpose(1, 2))
        x = self.projection(x).transpose(1, 2)

        x = self.rev(x, 'denorm') if self.rev else x
        return x
